from django.urls import include, path

from utilities.urls import get_model_urls

from . import views  # noqa: F401

app_name = 'netbox_cross_connects'

urlpatterns = [
    path('cross-connects/', include(get_model_urls(app_name, 'crossconnect', detail=False))),
    path('cross-connects/<int:pk>/', include(get_model_urls(app_name, 'crossconnect'))),
]
